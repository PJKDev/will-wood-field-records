const cfg = ARG_CONFIG;

const countdownLabel = document.getElementById("countdown-label");
const buttons = document.getElementById("buttons");

countdownLabel.textContent = cfg.countdownLabel || "TIME REMAINING";

function createButton(button) {
  const el = document.createElement("button");
  el.className = "arg-button";
  el.textContent = button.text || "BUTTON";

  el.style.left = `${button.x}%`;
  el.style.top = `${button.y}%`;

  if (!button.visible) {
    el.style.opacity = "0";
    el.style.border = "0";
    el.style.background = "transparent";
    el.style.color = "transparent";
  }

  el.addEventListener("click", () => {
    if (button.link) window.location.href = button.link;
  });

  buttons.appendChild(el);
}

function createGlitchSpot(spot) {
  const el = document.createElement("div");
  el.className = "glitch-spot";

  el.style.left = `${spot.x}%`;
  el.style.top = `${spot.y}%`;
  el.style.width = `${spot.width}px`;
  el.style.height = `${spot.height}px`;

  if (spot.visible) {
    el.style.opacity = ".25";
  }

  el.addEventListener("click", () => {
    if (spot.link) window.location.href = spot.link;
  });

  document.body.appendChild(el);
}

(cfg.buttons || []).forEach(createButton);
(cfg.hiddenSpots || []).forEach(createGlitchSpot);

const target = new Date(cfg.countdown).getTime();

function pad(number) {
  return String(Math.max(0, number)).padStart(2, "0");
}

function updateCountdown() {
  const difference = target - Date.now();

  if (difference <= 0) {
    document.getElementById("days").textContent = "00";
    document.getElementById("hours").textContent = "00";
    document.getElementById("minutes").textContent = "00";
    document.getElementById("seconds").textContent = "00";
    countdownLabel.textContent = "SIGNAL RECEIVED";
    return;
  }

  const totalSeconds = Math.floor(difference / 1000);

  const days = Math.floor(totalSeconds / 86400);
  const hours = Math.floor((totalSeconds % 86400) / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;

  document.getElementById("days").textContent = pad(days);
  document.getElementById("hours").textContent = pad(hours);
  document.getElementById("minutes").textContent = pad(minutes);
  document.getElementById("seconds").textContent = pad(seconds);
}

updateCountdown();
setInterval(updateCountdown, 1000);

// Random tiny glitches to make the page feel "wrong".
if (cfg.randomGlitches) {
  setInterval(() => {
    if (Math.random() > 0.45) {
      document.body.classList.add("flash");
      setTimeout(() => document.body.classList.remove("flash"), 120);
    }
  }, cfg.glitchFrequency || 5000);
}
