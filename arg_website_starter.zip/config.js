/*
  =========================
  ARG WEBSITE CONFIGURATION
  =========================

  This is the main file YOU edit.

  Date format:
  "YYYY-MM-DDTHH:MM:SS"

  Example:
  "2026-10-31T23:59:59"

  The browser uses the visitor's local time zone.
*/

const ARG_CONFIG = {

  // ===== COUNTDOWN =====
  countdown: "2026-10-31T23:59:59",

  // Text above the countdown
  countdownLabel: "TIME REMAINING",


  // ===== NORMAL BUTTONS =====
  //
  // x and y are percentages of the screen.
  // 50 = middle of the screen.
  //
  // visible: true  -> normal button
  // visible: false -> invisible but still clickable

  buttons: [
    {
      text: "ENTER",
      x: 50,
      y: 72,
      link: "https://example.com",
      visible: true
    }
  ],


  // ===== HIDDEN GLITCH SPOTS =====
  //
  // These are intentionally subtle clickable areas.
  //
  // You can change:
  // x/y       = location
  // width     = clickable width
  // height    = clickable height
  // link      = destination
  // visible   = false makes it very hard to notice
  //
  // You can add as many as you want.

  hiddenSpots: [
    {
      x: 78,
      y: 34,
      width: 35,
      height: 20,
      link: "https://example.com/secret",
      visible: false
    }
  ],


  // ===== GLITCH EFFECT =====
  randomGlitches: true,
  glitchFrequency: 5000
};
