ARG WEBSITE STARTER
====================

HOW TO USE
----------

1. Open index.html in a browser to test the website.

2. Open config.js in a text editor.

3. Change the countdown:

   countdown: "2026-10-31T23:59:59"

4. Change the normal button:

   text: "ENTER"
   x: 50
   y: 72
   link: "https://your-link-here.com"

5. Add/remove hidden glitch spots.

   hiddenSpots: [
     {
       x: 78,
       y: 34,
       width: 35,
       height: 20,
       link: "https://your-secret-link.com",
       visible: false
     }
   ]

   x/y are percentages of the screen.

6. To add another hidden spot, put a comma after the first one and add
   another object.

IMPORTANT:
----------

For a real public website, upload all four files to a static web host.
Keep index.html, style.css, script.js, and config.js in the same folder.

The countdown runs in the visitor's browser.

The hidden links are NOT truly secret/security-protected. Someone who
inspects the webpage source can find them. That is usually fine for an
ARG where the goal is discovery rather than security.

IDEA:
-----

You can make later ARG stages by changing the hidden link to another
page, for example:

https://your-site.com/room2.html

Then create room2.html with a completely different puzzle.
